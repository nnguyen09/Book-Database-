package com.example.group7bookstore;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

//This class handles the logged in page of the app, users that are logged in can check their order history and search books
public class Login extends AppCompatActivity {

    //declaring input and buttons
    EditText etSearch;
    Button searchQuery, histQuery;


    @Override
    protected  void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_page);
        TextView email = findViewById(R.id.email);

        //getting intent from main to display the email they logged in under
        Intent intent = getIntent();
        String get_email = intent.getStringExtra("email");
        email.setText(get_email);

        //setting up input fields and buttons
        etSearch = findViewById(R.id.search);
        searchQuery = findViewById(R.id.query);
        histQuery = findViewById(R.id.history);

        //creating on click listener for search button
        searchQuery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Search requires input from the search field, retrievs that input here
                String search = etSearch.getText().toString();
                //Setting up response listener that waits for the .php to respond
                Response.Listener<String> responseListener = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            Log.d("SubmitQueryHelp", response);
                            JSONObject jsonResponse = new JSONObject(response);
                            boolean success = jsonResponse.getBoolean("success");
                            //If it response with a success then they enetered in a valid search term
                            if(success){
                                //gets counter that is used to determine if there was more then one result (should only be the case if they searched by author)
                                int counter = jsonResponse.getInt("counter");
                                //setting up intent
                                Intent intent = new Intent(Login.this, Search.class);

                                //creating an array list
                                ArrayList<String> memList = new ArrayList<>(counter);

                                //adding first title and book price to the array list
                                String title_price = jsonResponse.getString("title") + "                              " + jsonResponse.getInt("price") +  ".99";
                                memList.add(title_price);

                                //if the counter is greater then 1(author search) goes in here to add the rest of the books
                                if(counter >1){
                                    for(int i = 0; i < counter; i++)
                                    {
                                        String title_price_it = jsonResponse.getString("title" + i) + "                              " + jsonResponse.getInt("price" + i)   +  ".99";
                                        memList.add(title_price_it);
                                    }
                                }

                                //after all books are added convers the array list to a normal array (spinner needs array)
                                String[] memArray = memList.toArray(new String[memList.size()]);
                                //Puts the array into intent
                                intent.putExtra("list", memArray);


                                Login.this.startActivity(intent);
                            }
                            //Else they did not enter a proper search term
                            else{
                                AlertDialog.Builder builder = new AlertDialog.Builder(Login.this);
                                builder.setMessage("Please enter book title or author name").setNegativeButton("Retry", null).create().show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                };

                //Sending query request
                QueryRequest queryRequest = new QueryRequest(search,getString(R.string.url) + "task1.php", responseListener);
                RequestQueue queue = Volley.newRequestQueue(Login.this);
                queue.add(queryRequest);
            }
        });

        //Setting on click listener for history button
        histQuery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //setting response listener for hist button that waits for .php to respond
                Response.Listener<String> responseListener = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            Log.d("SubmitQueryHelp", response);
                            JSONObject jsonResponse = new JSONObject(response);
                            boolean success = jsonResponse.getBoolean("success");
                            //if succes is true then they do have a search history to display otherwise they do not
                            if(success){
                                //Same setup as above except instead of book price it returns how many of the book they have purchased
                                int counter = jsonResponse.getInt("counter");
                                Intent intent = new Intent(Login.this, History.class);

                                if(counter >=1){

                                    ArrayList<String> memList = new ArrayList<>(counter);


                                    for(int i = 0; i < counter; i++)
                                    {
                                        String title_price_it = jsonResponse.getString("title" + i) + "                              " + jsonResponse.getInt("count" + i);
                                        memList.add(title_price_it);
                                    }


                                    String[] memArray = memList.toArray(new String[memList.size()]);
                                    intent.putExtra("list", memArray);

                                }
                                Login.this.startActivity(intent);
                            } else{
                                AlertDialog.Builder builder = new AlertDialog.Builder(Login.this);
                                builder.setMessage("Sign In Failed").setNegativeButton("Retry", null).create().show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                };
                QueryRequest queryRequest = new QueryRequest(get_email,getString(R.string.url) + "task2_hist.php", responseListener);
                RequestQueue queue = Volley.newRequestQueue(Login.this);
                queue.add(queryRequest);
            }
        });


    }

}
