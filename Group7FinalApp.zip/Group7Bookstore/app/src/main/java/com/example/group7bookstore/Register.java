package com.example.group7bookstore;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

//this class handles the page that takes in the info for registering a new user
public class Register extends AppCompatActivity {
    //declaring input text fields and submit button
    EditText etEmail, etPassword, etPhone, etName, etMember;
    Button submitReg;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_page);

        //setting up input and button
        etEmail = findViewById(R.id.email_reg);
        etPassword = findViewById(R.id.password_reg);
        etPhone = findViewById(R.id.phone);
        etName = findViewById(R.id.name);
        etMember = findViewById(R.id.mem);

        submitReg = findViewById(R.id.submit_register);

        //setting on click listener for button
        submitReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //On click it gets the info stored in the text fields
                String email = etEmail.getText().toString();
                String password = etPassword.getText().toString();
                String phone = etPhone.getText().toString();
                String name = etName.getText().toString();
                String member = etMember.getText().toString();

                //response listener that waits for a response from the .php file
                Response.Listener<String> responseListener = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try{
                            Log.d("SubmitQueryHelp", response);
                            JSONObject jsonResponse = new JSONObject(response);
                            boolean success = jsonResponse.getBoolean("success");
                            //if the php response with a success then it means a user was created and it logs them in under that user, with more time I would add another buffer page that confirms their details before login
                            if(success){
                                String email = jsonResponse.getString("email");

                                //setting intent for login page and giving it the email
                                Intent intent = new Intent(Register.this, Login.class);

                                intent.putExtra("email", email);

                                Register.this.startActivity(intent);

                            }
                            //if it doesnt return success then they entered something wrong, with more time i would make cases specific to the type of error they made IE didn't enter in X field responds as such
                            else{
                                AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                                builder.setMessage("Registration Failled").setNegativeButton("Retry", null).create().show();

                            }
                        }catch(JSONException e){
                            e.printStackTrace();
                        }
                    }
                };
                //Sends the input data to query request which gives it to the .php and waits for response
                QueryRequest queryRequest = new QueryRequest(email, password,phone,name, member, getString(R.string.url) + "task3.php", responseListener);
                RequestQueue queue = Volley.newRequestQueue(Register.this);
                queue.add(queryRequest);
            }
        });

    }

}
