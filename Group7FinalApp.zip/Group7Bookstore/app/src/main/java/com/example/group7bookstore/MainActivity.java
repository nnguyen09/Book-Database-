package com.example.group7bookstore;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

//This class is the main home page of the app, allows for searching book by title/author, finding best seller books of given or any year, login and registration
public class MainActivity extends AppCompatActivity {
    //Declaring input fields and buttons
    EditText etEmail, etPassword, etSearch, etBest;
    Button submitLogin, searchQuery, register, etBestSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //setting up input fields
        etEmail = findViewById(R.id.email);
        etPassword = findViewById(R.id.password);
        etSearch = findViewById(R.id.search1);
        etBest = findViewById(R.id.best_search);

        //setting up buttons
        submitLogin = findViewById(R.id.login);
        searchQuery = findViewById(R.id.query1);
        register = findViewById(R.id.register);
        etBestSearch = findViewById(R.id.best_seller);

        //Setting on click listener for best seller search button
        etBestSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //on click it gets the input they entered
                String search = etBest.getText().toString();

                //setting up response listener that waits for the .php to respond
                Response.Listener<String> responseListener = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            Log.d("SubmitQueryHelp", response);
                            JSONObject jsonResponse = new JSONObject(response);
                            boolean success = jsonResponse.getBoolean("success");
                            //If there is a succseful respond then their entered in a valid search (either no input or a year)
                            if(success){
                                //Counter is used to retriev multiple books (case they searched no year)
                                int counter = jsonResponse.getInt("counter");
                                Intent intent = new Intent(MainActivity.this, BestSeller.class);
                                //Setting up array list
                                ArrayList<String> memList = new ArrayList<>(counter);
                                //Adding first best seller to list(if they entered a valid year then this will be the only info)
                                String title_price ="Best Seller of year  "+ jsonResponse.getString("year0") + ":   " + jsonResponse.getString("title0") + "                    " + jsonResponse.getInt("price0") +  ".99";
                                memList.add(title_price);
                                //if the counter is greater then 1 that means they either didnt enter a year, or entered a year that does not have a best seller, in either case the php returns the best seller of all years
                                if(counter >1){
                                    for(int i = 0; i < counter; i++)
                                    {
                                        String title_price_it = "Best Seller of year  "+ jsonResponse.getString("year"+i) + ":   " +jsonResponse.getString("title" + i) + "                    " + jsonResponse.getInt("price" + i)   +  ".99";
                                        memList.add(title_price_it);
                                    }
                                }
                                //Convert the array list to a normal string array as spinner needs that to work
                                String[] memArray = memList.toArray(new String[memList.size()]);
                                intent.putExtra("list", memArray);


                                MainActivity.this.startActivity(intent);
                            } else{
                                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                                builder.setMessage("Sign In Failed").setNegativeButton("Retry", null).create().show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                };
                //Sends a query request to the task4.php
                QueryRequest queryRequest = new QueryRequest(search,getString(R.string.url) + "task4.php", responseListener);
                RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
                queue.add(queryRequest);
            }
        });
        //Setting up on click listener for the normal search button (this button handles search by author or title)
        searchQuery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //on click gets the input
                String search = etSearch.getText().toString();
                //setting up response listener which waits for the .php to respond
                Response.Listener<String> responseListener = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            Log.d("SubmitQueryHelp", response);
                            JSONObject jsonResponse = new JSONObject(response);
                            boolean success = jsonResponse.getBoolean("success");

                            //If success that means they enetered a valid search term
                            if(success){

                                //counter handles the cases where there are multiple results (if they searched by an author that has published more then one book)
                                int counter = jsonResponse.getInt("counter");
                                Intent intent = new Intent(MainActivity.this, Search.class);
                                //creating array list and adding the first book title and price to it, if they searched by title this will be the only thing added
                                ArrayList<String> memList = new ArrayList<>(counter);
                                String title_price = jsonResponse.getString("title") + "                              " + jsonResponse.getInt("price") +  ".99";
                                memList.add(title_price);
                                //if counter is greater then 1 they searched by author and that author has published more then one book, it therefore itterates through all the books returned by the php
                                if(counter >1){
                                    for(int i = 0; i < counter; i++)
                                    {
                                        String title_price_it = jsonResponse.getString("title" + i) + "                              " + jsonResponse.getInt("price" + i)   +  ".99";
                                        memList.add(title_price_it);
                                    }
                                }
                                //Converts the array list to a normal array so spinner can use it
                                String[] memArray = memList.toArray(new String[memList.size()]);
                                intent.putExtra("list", memArray);


                                MainActivity.this.startActivity(intent);
                            } else{
                                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                                builder.setMessage("Sign In Failed").setNegativeButton("Retry", null).create().show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                };
                QueryRequest queryRequest = new QueryRequest(search,getString(R.string.url) + "task1.php", responseListener);
                RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
                queue.add(queryRequest);
            }
        });


        //Setting up on click listener for the login button
        submitLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //log in takes the email and password as input
                String email = etEmail.getText().toString();
                String password = etPassword.getText().toString();

                //setting up response listener that waits for the php to respond
                Response.Listener<String> responseListener = new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {

                        try{
                            Log.d("SubmitQueryHelp", response);
                            JSONObject jsonResponse = new JSONObject(response);
                            boolean success = jsonResponse.getBoolean("success");
                            //if succesful that means they entered a valid username and password and lets them log in
                            if(success){

                                String email = jsonResponse.getString("email");

                                Intent intent = new Intent(MainActivity.this, Login.class);

                                intent.putExtra("email", email);

                                MainActivity.this.startActivity(intent);

                            }else{
                                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                                builder.setMessage("Sign In Failed").setNegativeButton("Retry", null).create().show();
                            }

                        }catch(JSONException e){

                            e.printStackTrace();
                        }
                    }
                };

                QueryRequest queryRequest = new QueryRequest(email, password, getString(R.string.url) + "task2.php", responseListener);
                RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
                queue.add(queryRequest);

            }
        });

        //Setting up on click listener for the register button, all it does is on click send them to the Register class and register_page to handle their registration
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, Register.class);
                String h = "hello";
                intent.putExtra("Hello", h);
                MainActivity.this.startActivity(intent);
            }
        });


    }
}