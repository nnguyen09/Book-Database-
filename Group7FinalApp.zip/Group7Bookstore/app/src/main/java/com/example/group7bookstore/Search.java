package com.example.group7bookstore;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

//Class that handles the output screen for user search query
public class Search extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.book_search_result);
        //gets textviews
        TextView book_title_field = (TextView) findViewById(R.id.bookTitle);
        TextView price_field = (TextView) findViewById(R.id.bookPrice);

        //gets intent
        Intent intent = getIntent();
        //getting array string passed into intent by main
        final String[] list = intent.getStringArrayExtra("list");

        //Setting spinner to hold the values it was passed (in this case book titles with the price associated with them
        Spinner s = (Spinner) findViewById(R.id.list);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(adapter);


    }

}
