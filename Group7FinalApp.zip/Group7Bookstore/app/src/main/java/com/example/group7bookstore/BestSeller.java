package com.example.group7bookstore;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

//This class handles the best seller list, is almost identical to the search except the array also has the year the book is the best seller of
public class BestSeller extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.best_seller);

        TextView book_title_field = (TextView) findViewById(R.id.best_bookTitle);
        TextView price_field = (TextView) findViewById(R.id.best_bookPrice);


        Intent intent = getIntent();
        final String[] list = intent.getStringArrayExtra("list");

        Spinner s = (Spinner) findViewById(R.id.best_list);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(adapter);


    }
}
