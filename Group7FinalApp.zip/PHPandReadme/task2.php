<?php
//This php handles the bookstore apps login

session_start();
$bool = false;

//connecting to database
$mysqli = new mysqli('localhost', 'root', '', 'bookstore');

//getting email and password entered
$email = $_POST['email'];
$password = $_POST['password'];
$_SESSION['email'] = $_POST['email'];

	//Setting up queries, 1 for nonmember login, 2 for member login
	$q1 = "Select * from non_member where email = '$email' and password= '$password' ";
	$q2 = "Select * from member where email = '$email' and password= '$password' ";
	$r1 = $mysqli->query(($q1));
	$r2 = $mysqli->query(($q2));
	//if 1 returns 0 then they arent a non-member
    if($r1->num_rows == 0)
	{
		//If r2 has no results then that means they are not a member either
		if($r2->num_rows == 0)
		{
			//If they entered in a password and email and got here it means they entered in the wrong email and password, so it tells them
			if(($email!='' )&&($password!=''))
			{
				//sends fail state to app
				$response["success"] = "false";
				echo json_encode($response);
				unset($_SESSION['email']);
			}
		}
		//Else it does return results and therefore they are a member and can log in
		else
		{
			$testrow = mysqli_fetch_array($r2);

			$response["password"] = $testrow['password']; 
			$response["email"] = $testrow['email'];		
	
			$response["success"] = "true";
			echo json_encode($response);
	}
	}
	//else they are a non member and they can log in
	else
	{
		$testrow = mysqli_fetch_array($r1);

		$response["password"] = $testrow['password'];
		$response["email"] = $testrow['email'];

		$response["success"] = "true";
		echo json_encode($response);
	}
?>