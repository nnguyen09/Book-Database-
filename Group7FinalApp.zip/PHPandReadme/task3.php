<?php
//This php handles the bookstore apps registration 

//getting input from user
$email = $_POST['email'];
$password = $_POST['password'];
$membership = $_POST['member'];
$name = $_POST['name'];
$phone_number = $_POST['phone'];

//connecting to server
$mysqli = new mysqli('localhost', 'root', '', 'bookstore');


//First inserting their info into user table
$qu1 = "INSERT INTO users (email,name) values ('$email' ,'$name')";
if($mysqli->query($qu1)){//echo "Account created succesfully<br>";
}
else{
	$response["success"] = "Fail";
	echo json_encode($response);
	//echo "Error1" . $qu1 ."<br>" . mysqli_error($myconnection);
	}

//then inserting them into customer
$qu2 = "INSERT INTO customer (email,name,phone_number) values ('$email' ,'$name','$phone_number')";
if($mysqli->query($qu2)){//echo "Registered as a customer<br>";
}
else{
	$response["success"] = "Fail";
	echo json_encode($response);
	//echo "Error2" . $qu2 ."<br>" . mysqli_error($myconnection);
	}

//generate cart id
do
{
	$cart_id = strval(rand(0,9999));
	$qtestid = "SELECT * FROM cart where cart_id = '$cart_id'";
	$result = $mysqli->query($qtestid);
}while(mysqli_num_rows($result) != 0);

//Inserting the new cart
$qcart = "insert into cart (cart_id, user_email, item_cost, shipping_type, tax) values ('$cart_id','$email', 0.0, 'standard', 5)";
if($mysqli->query($qcart)){//echo "Cart created";
}
else{
	$response["success"] = "Fail";
	echo json_encode($response);
	//echo "Error2" . $qcart ."<br>" . mysqli_error($myconnection);
	}

//If they clicked yes for member ship then it inserts them into member
if($membership == 'yes'){
    $qu3 = "INSERT INTO member (email,name,phone_number,member_fee,password) values ('$email' ,'$name','$phone_number','20.00', '$password')";    
    if($mysqli->query($qu3))
	{
        //echo "Registered as a Member under '$email'";
		//Sets session email to the email they provided
		$_SESSION['email'] = $email;
		$response["email"] = $email;
		$response["success"] = "true";
		echo json_encode($response);
    
	}
    else{
		$response["success"] = "fail";
		echo json_encode($response);
		//echo "Error3" . $qu3 ."<br>" . mysqli_error($myconnection);
		}
}

//If they clicked premium sets them up as a member that is a premium user with a higher monthly payment
if($membership == 'premium'){
    $qu4 = "INSERT INTO member (email,name,phone_number,member_fee,password) values ('$email' ,'$name','$phone_number','50.00', '$password')";
    if($mysqli->query($qu4))
	{
		//echo "Registered as a premium member under '$email'";
		//Sets session email to the email they provided
		$_SESSION['email'] = $email;
		$response["email"] = $email;
		$response["success"] = "true";
		echo json_encode($response);
    }
    else{
		$response["success"] = "fail";
		echo json_encode($response);
		//echo "Error4" . $qu4 ."<br>" . mysqli_error($myconnection);
		}
}

//if they selected no then they get inserted into nonmember
if($membership == 'no'){
    $qu5 = "INSERT INTO non_member (email,name,phone_number,password) values ('$email' ,'$name','$phone_number', '$password')";
    if($mysqli->query($qu5))
	{
		//echo "Registered as a non_member under '$email'";		
		//Sets session email to the email they provided
		$_SESSION['email'] = $email;
		$response["email"] = $email;
		$response["success"] = "true";
		echo json_encode($response);
    }
    else{
		$response["success"] = "fail";
		echo json_encode($response);
		//echo "Error5" . $qu5 ."<br>" . mysqli_error($myconnection);
		}
}


?>