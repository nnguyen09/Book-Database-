<?php

//This php handles the bookstore apps search engine

session_start();

//getting connected to server
$mysqli = new mysqli('localhost', 'root', '', 'bookstore');

//getting the search word entered
$search = $_POST['search'];


//Finding book assuming it is a title used
$qGetInfo = "SELECT * FROM book WHERE title ='$search'";
$result = $mysqli->query($qGetInfo);

//if 0 then it wasnt a title searched
if(mysqli_num_rows($result) == 0) 
{
	//Checking to see if it is an author that was used as the search term
	$qGetInfo = "SELECT * FROM book WHERE book_id in (select book_id from wrote where author_id in (select author_id from author where name = '$search'))";
	$result = $mysqli->query($qGetInfo);
	
	//if 0 then it wasnt an author meaning they did not enter a valid search term
	if(mysqli_num_rows($result) == 0)
	{
		//Responding to app with fail state
		$response["success"] = "false";
		echo json_encode($response);
	}
}

//getting the results of the query, if no results then these will all be empty and it will not return anything
$testrow = mysqli_fetch_array($result);

//iterates through all results, if they searched by author then it enters the while loop as there is multiple results
$response["title"] = $testrow['title'];
$response["price"] = $testrow['price'];
$counter = 0;
while($row = mysqli_fetch_array($result))
{
$response["title".$counter] = $row['title'];
$response["price".$counter] = $row['price'];
$counter++;
}
$response["counter"] = $counter;
$response["success"] = "true";
echo json_encode($response);
?>
