In order to properly run this program you must first have a xampp setup with apache and MySql running
You also need android studio downloaded on your computer with an emulator that has API 30 or eirler installed

After those are runnig you need to go to http://localhost/phpmyadmin/ click on import, chose the DB2.sql
file and click the go button in the bottom right corner, this will create the base bookstore database that 
will be accessed and updated by the website. 



You also need to place all of these .html and php files inside of your computers /htdocs folder. if you 
nest them inside another folder, for instance /bookstore then you need to keep track of the directory

then you need to place the Group7Bookstore inside your AndroidStudioProjects folder and open it in android studio

once you do that navigate to AndroidStudioProjects\Group7Bookstore\app\src\main\res\values\strings.xml and edit
the <string name="url">http://xxx.x.x.x/</string> to your own ip address (can be obtained via ipconfig in the terminal)

IMPORTANT: If you nested the php files the url needs to be editied to reflect that 
for instance if you placed it in a folder inside htdocs titled bookstore the url must be
<string name="url">http://YOURIPADDRESS/bookstore/</string>
if this is not done the app will not know how to access the php files

Once all of this is done you should be able to run the program, it will start on the main activity page 
which allows for users to search books by title or author, find the bestseller book of a given year or all,
log in, or register. if clicking register it will lead to the registration page, if they log in it will lead
them to the logged in page where the user can view their order history.