<?php

//This php handles the bookstore apps user history retrival
session_start();
$user = "bookstore";
$bool = false;
$mysqli = new mysqli('localhost', 'root', '', 'bookstore');

//gets the email it is working with
$email =$_POST['search'];

//Query that gets the count of the book they bought
$q1 ="select count(book_id) as quantity from grab where order_id in (select order_id from history where email ='$email') group by book_id";
$r1 = $mysqli->query(($q1));

//query that gets the info of books they have gotten, if zero then they have no history so returns fail state 
$q2 ="select * from book where book_id in (select book_id from grab where order_id in (select order_id from history where email ='$email'))";
$r2 = $mysqli->query(($q2));
if($r1->num_rows == 0)
{
        $response["success"] = "Fail";
		echo json_encode($response);
}
else{
	
//itterates through all their books and sends the info to the app
$counter = 0;
while($row = mysqli_fetch_array($r1))
{
$response["count".$counter] = $row['quantity'];
$row2 = mysqli_fetch_array($r2);
$response["title".$counter] = $row2['title'];
$counter++;
}
$response["counter"] = $counter;

    $response["success"] = "true";
	echo json_encode($response);
		
}

?>