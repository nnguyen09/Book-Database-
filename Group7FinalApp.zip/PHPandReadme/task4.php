<?php
//This file gets the bestselling books of each year

//Starting session
session_start();

//Getting year they input
$year_provided = $_POST['search'];

//getting connection to database
$myconnection = mysqli_connect('localhost', 'root', '') 
or die ('Could not connect: ' . mysql_error());
$mydb = mysqli_select_db ($myconnection, 'bookstore') or die ('Could not select database');

//If they didn't enter a year then it will output the best seller of each year
if($_POST['search']==''){



//Query to get each year that has a bestseller
$get_years = "select a.years from (select max(a.cnt) as max_per_year, year(a.year_bought) as years  from (select count(book_id) as cnt, book_id, year_bought from grab group by book_id, year_bought)as a group by a.year_bought) as a";
$r1 = mysqli_query($myconnection, $get_years);
//Query to get the rows from book that are the best seller of each year 
$q2 = "select * from book where book_id in (select a.book_id from
(select count(book_id) as cnt, book_id, year_bought from grab group by book_id, year_bought) as a,
(select max(a.cnt) as max_per_year, a.year_bought as years  from (select count(book_id) as cnt, book_id, year_bought from grab group by book_id, year_bought)as a group by a.year_bought) as b 
where a.cnt = b.max_per_year and b.years = a.year_bought)";
$result = mysqli_query($myconnection, $q2);


$counter = 0;
while($row = mysqli_fetch_array($result)){
	$response["title".$counter] = $row['title'];
	$response["price".$counter] = $row['price'];
	$row2 = mysqli_fetch_array($r1);
	$response["year".$counter] = $row2['years'];
	$counter++;
}
$response["counter"] = $counter;
$response["success"] = "true";
echo json_encode($response);
}
//The else handles when they did enter a year
if($_POST['search']!=''){
//Query that gets the best selling book of the provided year
$q1 = "select * from book where book_id in (select a.book_id from
(select count(book_id) as cnt, book_id, year(year_bought) as years from grab group by book_id, years) as a,
(select max(a.cnt) as max_per_year, year(a.year_bought) as years  from (select count(book_id) as cnt, book_id, year_bought from grab group by book_id, year_bought)as a group by a.year_bought) as b 
where a.cnt = b.max_per_year and b.years = a.years and b.years = '$year_provided')";
$result = mysqli_query($myconnection, $q1);

//If it has zero rows it means there was no best seller of that year, therefore outputs bestsellers of all years like above
if(mysqli_num_rows($result) == 0)
{
//echo "No best seller of that year, here are some other hits though!!";
$get_years = "select a.years from (select max(a.cnt) as max_per_year, year(a.year_bought) as years  from (select count(book_id) as cnt, book_id, year_bought from grab group by book_id, year_bought)as a group by a.year_bought) as a";
$r1 = mysqli_query($myconnection, $get_years);
$q2 = "select * from book where book_id in (select a.book_id from
(select count(book_id) as cnt, book_id, year_bought from grab group by book_id, year_bought) as a,
(select max(a.cnt) as max_per_year, a.year_bought as years  from (select count(book_id) as cnt, book_id, year_bought from grab group by book_id, year_bought)as a group by a.year_bought) as b 
where a.cnt = b.max_per_year and b.years = a.year_bought)";
$result = mysqli_query($myconnection, $q2);



$counter = 0;
while($row = mysqli_fetch_array($result)){
	$response["title".$counter] = $row['title'];
	$response["price".$counter] = $row['price'];
	$row2 = mysqli_fetch_array($r1);
	$response["year".$counter] = $row2['years'];
	$counter++;
}
$response["counter"] = $counter;
$response["success"] = "true";
echo json_encode($response);
}
//Else it has a result for that year, therefore it only outputs that best selling book
else
{
	

	$counter = 0;
	while($row = mysqli_fetch_array($result)){
	$response["title".$counter] = $row['title'];
	$response["price".$counter] = $row['price'];
	$response["year".$counter] = $_POST['search'];
}
$response["counter"] = $counter;
$response["success"] = "true";
echo json_encode($response);

}
}
else{
		$response["success"] = "false";
		echo json_encode($response);
}


?>


