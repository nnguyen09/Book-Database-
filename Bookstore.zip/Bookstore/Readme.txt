In order to properly run this program you must first have a xampp setup with apache and MySql running

After those are runnig you need to go to http://localhost/phpmyadmin/ click on import, chose the DB2.sql
file and click the go button in the bottom right corner, this will create the base bookstore database that 
will be accessed and updated by the website. 

You also need to place all of these .html and php files inside of your computers /htdocs folder. if you 
nest them inside another folder, for instance /bookstore then to load up the starting page you would type
http://localhost/bookstore/bookstore.html
the .html is the starting point of accessing the website and from there you can navigate the website like you
would most websites, you can search for books based off desired crytieria, you can create an account and log in 
with it, and when you log in you have even more options to work with from adding items to a cart, purchasing 
the cart, checking order history, to name a few.