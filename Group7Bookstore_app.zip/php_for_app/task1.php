<?php
session_start();
$mysqli = new mysqli('localhost', 'root', '', 'bookstore');
$search = $_POST['search'];



$qGetInfo = "SELECT * FROM book WHERE title ='$search'";

$result = $mysqli->query($qGetInfo);

if(mysqli_num_rows($result) == 0) 
{
	$qGetInfo = "SELECT * FROM book WHERE book_id in (select book_id from wrote where author_id in (select author_id from author where name = '$search'))";
	$result = $mysqli->query($qGetInfo);
	if(mysqli_num_rows($result) == 0)
	{
		$response["success"] = "false";
		echo json_encode($response);
	}
}

$testrow = mysqli_fetch_array($result);


$response["title"] = $testrow['title'];
$response["price"] = $testrow['price'];
$counter = 0;
while($row = mysqli_fetch_array($result))
{
$response["title".$counter] = $row['title'];
$response["price".$counter] = $row['price'];
$counter++;
}
$response["counter"] = $counter;
$response["success"] = "true";
echo json_encode($response);
?>
