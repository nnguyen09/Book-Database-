package com.example.group7bookstore;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class History extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.history_results);

        TextView book_title_field = (TextView) findViewById(R.id.book_Title);
        TextView quantity_field = (TextView) findViewById(R.id.quantity);


        Intent intent = getIntent();
        final String[] list = intent.getStringArrayExtra("list");

        Spinner s = (Spinner) findViewById(R.id.his_list);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(adapter);

    }
}
