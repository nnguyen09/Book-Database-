package com.example.group7bookstore;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class Register extends AppCompatActivity {
    EditText etEmail, etPassword, etPhone, etName, etMember;
    Button submitReg;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_page);

        etEmail = findViewById(R.id.email_reg);
        etPassword = findViewById(R.id.password_reg);
        etPhone = findViewById(R.id.phone);
        etName = findViewById(R.id.name);
        etMember = findViewById(R.id.mem);

        submitReg = findViewById(R.id.submit_register);


        submitReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = etEmail.getText().toString();
                String password = etPassword.getText().toString();
                String phone = etPhone.getText().toString();
                String name = etName.getText().toString();
                String member = etMember.getText().toString();

                Response.Listener<String> responseListener = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try{
                            Log.d("SubmitQueryHelp", response);
                            JSONObject jsonResponse = new JSONObject(response);
                            boolean success = jsonResponse.getBoolean("success");
                            if(success){
                                String email = jsonResponse.getString("email");

                                Intent intent = new Intent(Register.this, Login.class);

                                intent.putExtra("email", email);

                                Register.this.startActivity(intent);

                            }
                            else{
                                AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                                builder.setMessage("Registration Failled").setNegativeButton("Retry", null).create().show();

                            }
                        }catch(JSONException e){
                            e.printStackTrace();
                        }
                    }
                };
                QueryRequest queryRequest = new QueryRequest(email, password,phone,name, member, getString(R.string.url) + "task3.php", responseListener);
                RequestQueue queue = Volley.newRequestQueue(Register.this);
                queue.add(queryRequest);
            }
        });

    }

}
