package com.example.group7bookstore;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText etEmail, etPassword, etSearch;
    Button submitLogin, searchQuery, register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //setting up input fields
        etEmail = findViewById(R.id.email);
        etPassword = findViewById(R.id.password);
        etSearch = findViewById(R.id.search1);

        //setting up buttons
        submitLogin = findViewById(R.id.login);
        searchQuery = findViewById(R.id.query1);
        register = findViewById(R.id.register);

        searchQuery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String search = etSearch.getText().toString();

                Response.Listener<String> responseListener = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            Log.d("SubmitQueryHelp", response);
                            JSONObject jsonResponse = new JSONObject(response);
                            boolean success = jsonResponse.getBoolean("success");

                            if(success){

                                int counter = jsonResponse.getInt("counter");
                                Intent intent = new Intent(MainActivity.this, Search.class);
                                ArrayList<String> memList = new ArrayList<>(counter);
                                String title_price = jsonResponse.getString("title") + "                              " + jsonResponse.getInt("price") +  ".99";
                                memList.add(title_price);
                                if(counter >1){
                                    for(int i = 0; i < counter; i++)
                                    {
                                        String title_price_it = jsonResponse.getString("title" + i) + "                              " + jsonResponse.getInt("price" + i)   +  ".99";
                                        memList.add(title_price_it);
                                    }
                                }
                                String[] memArray = memList.toArray(new String[memList.size()]);
                                intent.putExtra("list", memArray);


                                MainActivity.this.startActivity(intent);
                            } else{
                                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                                builder.setMessage("Sign In Failed").setNegativeButton("Retry", null).create().show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                };
                QueryRequest queryRequest = new QueryRequest(search,getString(R.string.url) + "task1.php", responseListener);
                RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
                queue.add(queryRequest);
            }
        });


        //Start of handing the log in button press
        submitLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = etEmail.getText().toString();
                String password = etPassword.getText().toString();

                Response.Listener<String> responseListener = new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {

                        try{
                            Log.d("SubmitQueryHelp", response);
                            JSONObject jsonResponse = new JSONObject(response);
                            boolean success = jsonResponse.getBoolean("success");
                            if(success){

                                String email = jsonResponse.getString("email");

                                Intent intent = new Intent(MainActivity.this, Login.class);

                                intent.putExtra("email", email);

                                MainActivity.this.startActivity(intent);

                            }else{
                                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                                builder.setMessage("Sign In Failed").setNegativeButton("Retry", null).create().show();
                            }

                        }catch(JSONException e){

                            e.printStackTrace();
                        }
                    }
                };

                QueryRequest queryRequest = new QueryRequest(email, password, getString(R.string.url) + "task2.php", responseListener);
                RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
                queue.add(queryRequest);

            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, Register.class);
                String h = "hello";
                intent.putExtra("Hello", h);
                MainActivity.this.startActivity(intent);
            }
        });


    }
}